<?php

class UserController {

    private $userModel;

    public function __construct() {
        $this->userModel = new User();
    }

    /**
     * POST /api.php?action=register
     * Register a new user
     */
    public function register() {
        $data = json_decode(file_get_contents('php://input'), true);

        $username = trim($data['username'] ?? '');
        $password = $data['password'] ?? '';
        
        // Sanitize username - only allow alphanumeric and underscores
        $username = preg_replace('/[^a-zA-Z0-9_]/', '', $username);

        if (empty($username) || empty($password)) {
            $this->error('Username and password are required.', 400);
        }

        if (strlen($password) < 8) {
            $this->error('Password must be at least 8 characters long.', 400);
        }
        
        // Password strength validation
        if (!preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password)) {
            $this->error('Password must contain at least one uppercase letter, one lowercase letter, and one number.', 400);
        }
        
        // Check username length
        if (strlen($username) < 3 || strlen($username) > 50) {
            $this->error('Username must be between 3 and 50 characters.', 400);
        }

        if ($this->userModel->findByUsername($username)) {
            $this->error('Username already exists.', 409); // 409 Conflict
        }

        $userId = $this->userModel->create($username, $password);
        if (!$userId) {
            $this->error('Could not create user record in the database.', 500);
        }

        // Physically create the user's root folder on the file system
        $config = require dirname(dirname(__DIR__)) . '/config/app.php';
        // Build a clean, OS-agnostic path using Path helper when available
        if (class_exists('Path')) {
            $userFolderPath = Path::buildUserFsPath($username);
        } else {
            $projectRoot = dirname(dirname(__DIR__));
            $userFolderPath = $projectRoot . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . ltrim($config['upload_dir'], '/') . DIRECTORY_SEPARATOR . $username;
        }

        if (!is_dir($userFolderPath)) {
            if (!mkdir($userFolderPath, 0775, true)) {
                // This is a critical file system error.
                $this->logError("Failed to create user root directory: " . $userFolderPath . ". Permissions issue?");
                $this->error('User was created, but could not create the user\'s folder on the file system. Check server permissions.', 500);
            }
        }

        // Automatically create a root folder for the new user in the database
        $folderModel = new Folder();
        $folderCreated = $folderModel->create($username, $userId, "Root folder for " . $username);

        if (!$folderCreated) {
            $this->error('User and physical folder were created, but failed to create the folder record in the database.', 500);
        }

        $this->response(['success' => true, 'message' => 'User registered successfully.', 'userId' => $userId], 201);
    }

    /**
     * POST /api.php?action=login
     * Log in a user
     */
    public function login() {
        $data = json_decode(file_get_contents('php://input'), true);

        $username = trim($data['username'] ?? '');
        $password = $data['password'] ?? '';
        
        // Rate limiting for login attempts
        if (!isset($_SESSION['login_attempts'])) {
            $_SESSION['login_attempts'] = [];
        }
        
        $now = time();
        $_SESSION['login_attempts'] = array_filter($_SESSION['login_attempts'], function($timestamp) use ($now) {
            return ($now - $timestamp) < 300; // 5 minute window
        });
        
        if (count($_SESSION['login_attempts']) >= 5) {
            $this->error('Too many login attempts. Please try again in 5 minutes.', 429);
        }

        if (empty($username) || empty($password)) {
            $this->error('Username and password are required.', 400);
        }

        $user = $this->userModel->findByUsername($username);

        if ($user && password_verify($password, $user['password_hash'])) {
            // Clear login attempts on successful login
            $_SESSION['login_attempts'] = [];
            
            // Regenerate session ID to prevent session fixation
            session_regenerate_id(true);
            
            // Start session and store user data
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['ip_address'] = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
            $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';

            // Track session in active_sessions table
            try {
                $db = Database::getInstance();
                $stmt = $db->prepare("
                    INSERT INTO active_sessions (session_id, user_id, username, ip_address, user_agent, started_at, last_activity)
                    VALUES (?, ?, ?, ?, ?, NOW(), NOW())
                    ON DUPLICATE KEY UPDATE last_activity = NOW()
                ");
                $stmt->execute([
                    session_id(),
                    $user['id'],
                    $user['username'],
                    $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                    $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
                ]);
            } catch (Exception $e) {
                error_log("Failed to track session: " . $e->getMessage());
            }

            $this->response([
                'success' => true, 
                'message' => 'Login successful.',
                'user' => [
                    'id' => $user['id'],
                    'username' => $user['username']
                ]
            ]);
        } else {
            // Track failed login attempt
            $_SESSION['login_attempts'][] = time();
            
            // Use same error message to prevent username enumeration
            $this->error('Invalid username or password.', 401); // 401 Unauthorized
        }
    }

    /**
     * GET /api.php?action=check_status
     * Check if a user is logged in via session.
     */
    public function checkStatus() {
        if (isset($_SESSION['user_id']) && isset($_SESSION['username'])) {
            $this->response([
                'success' => true,
                'logged_in' => true,
                'user' => [
                    'id' => $_SESSION['user_id'],
                    'username' => $_SESSION['username']
                ]
            ]);
        } else {
            $this->response(['success' => true, 'logged_in' => false]);
        }
    }

    /**
     * GET /api.php?action=get_oauth_error
     * Get OAuth error from session (if any)
     */
    public function getOAuthError() {
        $error = $_SESSION['oauth_error'] ?? null;
        
        if ($error) {
            unset($_SESSION['oauth_error']);
            $this->response(['error' => $error]);
        } else {
            $this->response(['error' => null]);
        }
    }

    /**
     * POST /api.php?action=logout
     * Log out a user
     */
    public function logout() {
        // Remove session from active_sessions table
        try {
            $db = Database::getInstance();
            $stmt = $db->prepare("DELETE FROM active_sessions WHERE session_id = ?");
            $stmt->execute([session_id()]);
        } catch (Exception $e) {
            error_log("Failed to remove session: " . $e->getMessage());
        }
        
        session_unset();
        session_destroy();
        $this->response(['success' => true, 'message' => 'Logout successful.']);
    }

    /**
     * GET /api.php?action=get_profile
     * Get current user's profile information
     */
    public function getProfile() {
        if (!isset($_SESSION['user_id'])) {
            $this->error('Not logged in', 401);
            return;
        }

        $user = $this->userModel->findById($_SESSION['user_id']);
        if (!$user) {
            $this->error('User not found', 404);
            return;
        }

        $this->response([
            'success' => true,
            'user' => [
                'id' => $user['id'],
                'username' => $user['username'],
                'email' => $user['email'] ?? null,
                'created_at' => $user['created_at'],
                'last_login' => $user['last_login'] ?? null,
                'oauth_provider' => $user['oauth_provider'] ?? null,
                'avatar_url' => $user['avatar_url'] ?? null
            ]
        ]);
    }

    /**
     * POST /api.php?action=update_email
     * Update user's email address
     */
    public function updateEmail() {
        if (!isset($_SESSION['user_id'])) {
            $this->error('Not authenticated', 401);
            return;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $email = trim($data['email'] ?? '');

        if (empty($email)) {
            $this->error('Email is required', 400);
            return;
        }
        
        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('Invalid email format', 400);
            return;
        }
        
        // Check if email is already in use by another user
        $existingUser = $this->userModel->findByEmail($email);
        if ($existingUser && $existingUser['id'] !== $_SESSION['user_id']) {
            $this->error('Email is already in use', 409);
            return;
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->error('Invalid email format', 400);
            return;
        }

        // Check if email is already taken
        $existingUser = $this->userModel->findByEmail($email);
        if ($existingUser && $existingUser['id'] != $_SESSION['user_id']) {
            $this->error('Email already in use', 409);
            return;
        }

        $updated = $this->userModel->updateEmail($_SESSION['user_id'], $email);
        if ($updated) {
            $this->response(['success' => true, 'message' => 'Email updated successfully']);
        } else {
            $this->error('Failed to update email', 500);
        }
    }

    /**
     * POST /api.php?action=change_password
     * Change user's password
     */
    public function changePassword() {
        if (!isset($_SESSION['user_id'])) {
            $this->error('Not logged in', 401);
            return;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $currentPassword = $data['current_password'] ?? '';
        $newPassword = $data['new_password'] ?? '';

        if (empty($currentPassword) || empty($newPassword)) {
            $this->error('Current password and new password are required', 400);
            return;
        }

        if (strlen($newPassword) < 8) {
            $this->error('New password must be at least 8 characters long', 400);
            return;
        }

        $user = $this->userModel->findById($_SESSION['user_id']);
        if (!$user) {
            $this->error('User not found', 404);
            return;
        }

        // OAuth users might not have passwords
        if (empty($user['password_hash'])) {
            $this->error('Cannot change password for OAuth accounts', 400);
            return;
        }

        if (!password_verify($currentPassword, $user['password_hash'])) {
            $this->error('Current password is incorrect', 401);
            return;
        }

        $updated = $this->userModel->updatePassword($_SESSION['user_id'], $newPassword);
        if ($updated) {
            $this->response(['success' => true, 'message' => 'Password changed successfully']);
        } else {
            $this->error('Failed to change password', 500);
        }
    }

    /**
     * GET /api.php?action=get_account_stats
     * Get user's account statistics
     */
    public function getAccountStats() {
        if (!isset($_SESSION['user_id'])) {
            $this->error('Not logged in', 401);
            return;
        }

        $imageModel = new Image();
        $folderModel = new Folder();
        
        // Get total images
        $totalImages = $imageModel->countByUser($_SESSION['user_id']);
        
        // Get total folders
        $totalFolders = $folderModel->countByUser($_SESSION['user_id']);
        
        // Get shared images count
        $sharedImages = $imageModel->countSharedByUser($_SESSION['user_id']);
        
        // Get storage used
        $storageUsed = $imageModel->getTotalSizeByUser($_SESSION['user_id']);

        $this->response([
            'success' => true,
            'stats' => [
                'total_images' => $totalImages,
                'total_folders' => $totalFolders,
                'shared_images' => $sharedImages,
                'storage_used' => $storageUsed
            ]
        ]);
    }

    /**
     * DELETE /api.php?action=delete_account
     * Delete user account and all associated data
     */
    public function deleteAccount() {
        if (!isset($_SESSION['user_id'])) {
            $this->error('Not logged in', 401);
            return;
        }

        $userId = $_SESSION['user_id'];
        $user = $this->userModel->findById($userId);
        
        if (!$user) {
            $this->error('User not found', 404);
            return;
        }

        // Delete user's physical files
        $config = require dirname(dirname(__DIR__)) . '/config/app.php';
        if (class_exists('Path')) {
            $userFolderPath = Path::buildUserFsPath($user['username']);
        } else {
            $projectRoot = dirname(dirname(__DIR__));
            $userFolderPath = $projectRoot . DIRECTORY_SEPARATOR . 'public' . DIRECTORY_SEPARATOR . ltrim($config['upload_dir'], '/') . DIRECTORY_SEPARATOR . $user['username'];
        }

        if (is_dir($userFolderPath)) {
            $this->deleteDirectory($userFolderPath);
        }

        // Delete user record (cascade will delete images and folders)
        $deleted = $this->userModel->delete($userId);
        
        if ($deleted) {
            session_unset();
            session_destroy();
            $this->response(['success' => true, 'message' => 'Account deleted successfully']);
        } else {
            $this->error('Failed to delete account', 500);
        }
    }

    /**
     * Recursively delete a directory
     */
    private function deleteDirectory($dir) {
        if (!is_dir($dir)) {
            return false;
        }

        $items = array_diff(scandir($dir), ['.', '..']);
        
        foreach ($items as $item) {
            $path = $dir . DIRECTORY_SEPARATOR . $item;
            
            if (is_dir($path)) {
                $this->deleteDirectory($path);
            } else {
                unlink($path);
            }
        }

        return rmdir($dir);
    }

    /**
     * Send JSON response
     */
    private function response($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    /**
     * Send error response
     */
    private function error($message, $statusCode = 500) {
        $this->response([
            'success' => false,
            'error' => $message
        ], $statusCode);
    }

    /**
     * Log errors to a specific folder_errors.log file.
     */
    private function logError($message) {
        $projectRoot = dirname(dirname(__DIR__));
        $logDir = $projectRoot . DIRECTORY_SEPARATOR . 'logs';
        if (!is_dir($logDir)) {
            if (!mkdir($logDir, 0755, true)) {
                // can't create logs dir; fall back to PHP error_log
                error_log($message);
                return;
            }
        }
        $logFile = $logDir . DIRECTORY_SEPARATOR . 'folder_errors.log';
        $entry = "[" . date('Y-m-d H:i:s') . "] " . $message . "\n";
        file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
    }


/**
 * Get 2FA status for current user
 */
public function get2FAStatus() {
    if (!isset($_SESSION['user_id'])) {
        $this->error('Unauthorized', 401);
    }
    
    $user = $this->userModel->findById($_SESSION['user_id']);
    
    if (!$user) {
        $this->error('User not found', 404);
    }
    
    $this->response([
        'success' => true,
        'data' => [
            'enabled' => (bool)$user['two_factor_enabled'],
            'method' => $user['two_factor_method']
        ]
    ]);
}

/**
 * Generate 2FA secret and backup codes
 */
public function generate2FASecret() {
    if (!isset($_SESSION['user_id'])) {
        $this->error('Unauthorized', 401);
    }
    
    require_once __DIR__ . '/../Utils/TwoFactorAuth.php';
    
    $user = $this->userModel->findById($_SESSION['user_id']);
    $secret = TwoFactorAuth::generateSecret();
    $backupCodes = TwoFactorAuth::generateBackupCodes();
    $qrCodeUrl = TwoFactorAuth::getQRCodeUrl($user['username'], $secret);
    
    $this->response([
        'success' => true,
        'secret' => $secret,
        'qr_code_url' => $qrCodeUrl,
        'backup_codes' => $backupCodes
    ]);
}

/**
 * Enable 2FA for current user
 */
public function enable2FA() {
    if (!isset($_SESSION['user_id'])) {
        $this->error('Unauthorized', 401);
    }
    
    require_once __DIR__ . '/../Utils/TwoFactorAuth.php';
    
    $data = json_decode(file_get_contents('php://input'), true);
    $method = $data['method'] ?? 'totp';
    $secret = $data['secret'] ?? '';
    $backupCodes = $data['backup_codes'] ?? [];
    
    // Verify TOTP code if using authenticator app
    if ($method === 'totp') {
        $verificationCode = $data['verification_code'] ?? '';
        
        if (!TwoFactorAuth::verifyTOTP($secret, $verificationCode)) {
            $this->error('Invalid verification code. Please try again.');
        }
    }
    
    // Hash backup codes before storing
    $hashedBackupCodes = array_map(function($code) {
        return password_hash($code, PASSWORD_DEFAULT);
    }, $backupCodes);
    
    $db = Database::getInstance();
    $stmt = $db->prepare("
        UPDATE users 
        SET two_factor_enabled = 1,
            two_factor_method = ?,
            two_factor_secret = ?,
            two_factor_backup_codes = ?
        WHERE id = ?
    ");
    $stmt->execute([
        $method,
        $secret,
        json_encode($hashedBackupCodes),
        $_SESSION['user_id']
    ]);
    
    $this->response([
        'success' => true,
        'message' => '2FA enabled successfully'
    ]);
}

/**
 * Disable 2FA for current user
 */
public function disable2FA() {
    if (!isset($_SESSION['user_id'])) {
        $this->error('Unauthorized', 401);
    }
    
    $db = Database::getInstance();
    $stmt = $db->prepare("
        UPDATE users 
        SET two_factor_enabled = 0,
            two_factor_method = NULL,
            two_factor_secret = NULL,
            two_factor_backup_codes = NULL
        WHERE id = ?
    ");
    $stmt->execute([$_SESSION['user_id']]);
    
    $this->response([
        'success' => true,
        'message' => '2FA disabled successfully'
    ]);
}

/**
 * Regenerate backup codes
 */
public function regenerateBackupCodes() {
    if (!isset($_SESSION['user_id'])) {
        $this->error('Unauthorized', 401);
    }
    
    require_once __DIR__ . '/../Utils/TwoFactorAuth.php';
    
    $user = $this->userModel->findById($_SESSION['user_id']);
    
    if (!$user['two_factor_enabled'] || $user['two_factor_method'] !== 'totp') {
        $this->error('2FA with authenticator app must be enabled first');
    }
    
    $backupCodes = TwoFactorAuth::generateBackupCodes();
    
    // Hash backup codes
    $hashedBackupCodes = array_map(function($code) {
        return password_hash($code, PASSWORD_DEFAULT);
    }, $backupCodes);
    
    $db = Database::getInstance();
    $stmt = $db->prepare("
        UPDATE users 
        SET two_factor_backup_codes = ?
        WHERE id = ?
    ");
    $stmt->execute([
        json_encode($hashedBackupCodes),
        $_SESSION['user_id']
    ]);
    
    $this->response([
        'success' => true,
        'backup_codes' => $backupCodes
    ]);
}

}