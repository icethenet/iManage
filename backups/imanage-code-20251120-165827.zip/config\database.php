<?php
/**
 * Database Configuration
 */

return [
    'host' => 'localhost',
    'port' => 3306,
    'database' => 'image_gallery',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
];
